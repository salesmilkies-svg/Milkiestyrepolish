from flask import Flask, render_template, request, redirect, url_for, session, flash
import os

app = Flask(__name__, template_folder='templates', static_folder='static')
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'x7k9p2m8q5w3z1t0r4y6u8i2o0p')  # Use env var or fallback
app.config['ENV'] = os.getenv('FLASK_ENV', 'production')
app.config['DEBUG'] = app.config['ENV'] == 'development'

@app.route('/')
def home():
    single = request.args.get('single', 0, type=int)
    sixpack = request.args.get('sixpack', 0, type=int)
    session['single'] = single
    session['sixpack'] = sixpack
    session.modified = True
    return render_template('home.html', single=single, sixpack=sixpack)

@app.route('/cart', methods=['GET', 'POST'])
def cart():
    product = request.args.get('product')
    quantity = request.args.get('quantity', type=int)
    single = request.args.get('single', session.get('single', 0), type=int)
    sixpack = request.args.get('sixpack', session.get('sixpack', 0), type=int)
    return render_template('cart.html', product=product, quantity=quantity, single=single, sixpack=sixpack)

@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    single = session.get('single', 0)
    sixpack = session.get('sixpack', 0)
    note = request.form.get('note', '')
    collection_location = request.form.get('collection_location', '')

    if request.method == 'POST':
        total_amount = single * 140.00 + sixpack * 790.00
        if total_amount <= 0:
            flash('Your cart is empty. Please add items before checking out.', 'error')
            return redirect(url_for('cart', single=single, sixpack=sixpack))
        if not collection_location:
            flash('Please select a collection location.', 'error')
            return redirect(url_for('cart', single=single, sixpack=sixpack))
        session['collection_location'] = collection_location
        session.modified = True
        flash('Checkout successful!', 'success')
        return redirect(url_for('profile'))

    return render_template('checkout.html', note=note, single=single, sixpack=sixpack, collection_location=collection_location)

@app.route('/profile')
def profile():
    single = session.get('single', 0)
    sixpack = session.get('sixpack', 0)
    profile = session.get('profile', {})
    return render_template('profile.html', single=single, sixpack=sixpack, profile=profile)

@app.route('/create_profile', methods=['POST'])
def create_profile():
    session['profile'] = {
        'business_name': request.form.get('business_name'),
        'address': request.form.get('address'),
        'phone': request.form.get('phone'),
        'email': request.form.get('email')
    }
    session.modified = True
    flash('Profile created successfully!', 'success')
    return redirect(url_for('profile'))

if __name__ == '__main__':
    app.run()