<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VickysApp</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='css/styles.css') }}">
    <!-- Include Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* When scrolled */
        
        .carousel-button {
            background-color: rgba(255, 255, 255, 1); /* Semi-transparent white */
            border: none;
            border-radius: 10px; /* More square-like with rounded corners */
            padding: 15px 25px; /* Adjusted padding for more square shape */
            cursor: pointer;
            font-size: 14px;
            opacity: 0.7; /* Initially semi-transparent */
            transition: all 0.2s ease; /* Transition for all properties */
            position: absolute;
            bottom: 5%;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1002; /* Ensure button is above other elements */
        }

        .carousel-button:hover {
            transform: scale(1.1); /* Slightly enlarge on hover */
        }
        
        /* When scrolled, button should be more interactive */
        .scrolled .carousel-button {
            opacity: 1;
            font-size: 18px; /* Increase font size */
            font-weight: bold; /* Make text bold */
            padding: 20px 30px; /* Increase button size */
        }        
        .scrolled .carousel img {
            opacity: 1;
            transform: scale(1) translate(-50%, -50%); /* Remove scaling if you want the image to fit exactly */
            width: 100%; /* Ensure the image fills the container width */
            height: 100%; /* Ensure the image fills the container height */
            object-fit: cover; /* This will make the image cover the entire container while maintaining aspect ratio */
            max-width: none; /* Remove any max-width restriction */
            max-height: none; /* Remove any max-height restriction */
        }

        .carousel-nav {
            position: absolute;
            bottom: 5%;
            background: rgba(255, 255, 255, 0.8);
            border: none;
            border-radius: 50%; /* Round buttons */
            width: 50px; /* Adjust size */
            height: 50px; /* Adjust size */
            cursor: pointer;
            font-size: 20px; /* Size of icon */
            opacity: 0; /* Initially hidden */
            transition: all 0.2s ease;
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10034; /* Above carousel button */
        }

        .carousel-nav.left {
            left: 5%; /* Position relative to the center */
        }

        .carousel-nav.right {
            right: 5%; /* Position relative to the center */
        }

        /* When scrolled */
        .scrolled .carousel-nav {
            opacity: 1;
        }

        .carousel-nav i {
            color: #000; /* Icon color */
        }

        .carousel-nav:hover {
            background: rgba(255, 255, 255, 1);
            transform: scale(1.1);
        }

        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }

        /* Navigation Bar */
        .navbar {
            background-color: #000; /* Black background */
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
            transition: top 0.3s; /* Smooth transition for hiding/showing */
        }

        /* Hide navbar on scroll down */
        .navbar.hide {
            top: -80px; /* Adjust based on navbar height */
        }

        /* Menu Button (Left) */
        .menu-button {
            background: none;
            border: none;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        /* Logo (Middle Button) */
        .logo-button {
            background: none;
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
        }

        .logo-button img {
            height: 80px; /* Adjust size as needed */
            width: auto;
        }

        /* Dropdown Menu */
        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #333; /* Dark background for dropdown */
            min-width: 160px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1001;
            top: 100%; /* Position below the menu button */
            left: 0;
        }

        .dropdown-content a {
            color: white;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #555; /* Hover effect */
        }

        /* Show dropdown on hover */
        .dropdown:hover .dropdown-content {
            display: block;
        }

        /* Full-screen background images */
        .background-section {
            height: 100vh; /* Full viewport height */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            position: relative;
        }

        /* Individual background images */
        #section1 {
            background-image: url("{{ url_for('static', filename='images/20250203_214423.png') }}");
        }

        #section2 {
            background-image: url("{{ url_for('static', filename='images/20250203_214423.png') }}");
        }

        #section3 {
            background-image: url("{{ url_for('static', filename='images/20250203_214423.png') }}");
        }

        #section4 {
            background-image: url("{{ url_for('static', filename='images/20250203_214423.png') }}");
        }

        #section5 {
            background-image: url("{{ url_for('static', filename='images/20250203_214423.png') }}");
        }

        /* Carousel Container */
        .carousel {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 70%; /* Adjust width as needed */
            height: 40%; /* Adjust height as needed */
            overflow: hidden;
            display: flex;
            justify-content: flex-start;
        }

        /* Carousel Images */
        .carousel img {
            width: 100%;
            height: auto; /* Maintain aspect ratio */
            max-height: 100%; /* Ensure height does not exceed container */
            opacity: 0.5; /* 50% opacity initially */
            object-fit: contain; /* Maintain aspect ratio without cropping */
            flex: 0 0 100%; /* Ensure each image takes full width */
            transition: all 1s ease;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        /* When scrolled - for both container and images */
        .scrolled .carousel {
            /* Adjustments for the carousel container when scrolled */
            width: 100%; /* Larger width when scrolled, adjust as needed */
            height: 52%; /* Larger height when scrolled, adjust as needed */
            /* Any other properties you want to change when scrolled */
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <div class="navbar" id="navbar">
        <!-- Menu Button with Dropdown -->
        <div class="dropdown">
            <button class="menu-button">☰ Menu</button>
            <!-- Dropdown Content -->
            <div class="dropdown-content">
                <a href="#">Home</a>
                <a href="#">Services</a>
                <a href="#">Pricing</a>
                <a href="#">About Us</a>
                <a href="#">Contact</a>
            </div>
        </div>

        <!-- Logo as Middle Button -->
        <button class="logo-button">
            <img src="{{ url_for('static', filename='images/20250126_135752.jpg') }}" alt="Logo">
        </button>

        <!-- Empty div to balance the flex layout -->
        <div style="width: 48px;"></div> <!-- Adjust width to match menu button -->
    </div>

    <!-- Background Sections -->
    <div id="section1" class="background-section">
        <!-- Carousel -->
        <div class="carousel">
            <img src="{{ url_for('static', filename='images/20250127_180938.png') }}" alt="Carousel Image 1" class="active">
            <img src="{{ url_for('static', filename='images/20250127_185924.png') }}" alt="Carousel Image 2">
            <img src="{{ url_for('static', filename='images/20250130_222834.png') }}" alt="Carousel Image 3">
            <img src="{{ url_for('static', filename='images/20250131_134431.png') }}" alt="Carousel Image 4">
            <img src="{{ url_for('static', filename='images/20250131_142826.png') }}" alt="Carousel Image 5">
        </div>
        <button class="carousel-button" data-index="0">Image 1</button>
        <button class="carousel-nav left" title="Previous">
            <i class="fas fa-chevron-left"></i>
        </button>
        <button class="carousel-nav right" title="Next">
            <i class="fas fa-chevron-right"></i>
        </button>
    </div>
    <div id="section2" class="background-section"></div>
    <div id="section3" class="background-section"></div>
    <div id="section4" class="background-section"></div>
    <div id="section5" class="background-section"></div>

    <!-- JavaScript for Navbar Scroll Behavior and Carousel -->
    <script>
        let lastScrollTop = 0;
        const navbar = document.getElementById("navbar");
        const section1 = document.getElementById("section1");
        const carousel = document.querySelector(".carousel");
        const carouselImages = document.querySelectorAll(".carousel img");
        let currentIndex = 0;
        let carouselInterval;
        const carouselButton = document.querySelector(".carousel-button");

        function updateButton(index) {
            const buttonTexts = [
            "Glass Reborn!",
            "Transform your Electronics!",
            "Wood, Paper, Rubber - Renewed!",
            "Turn Textiles into Treasure",
            "Plastic with a Purpose"
            ];
            carouselButton.textContent = buttonTexts[index] || "Image " + (index + 1); // Fallback to a generic label if no text is defined
            carouselButton.setAttribute('data-index', index);
        }

        // Function to show the next image in the carousel
        function showNextImage() {
            // Hide current image
            carouselImages[currentIndex].style.opacity = '0';
            
            // Move to next image
            currentIndex = (currentIndex + 1) % carouselImages.length;
            
            // Update button
            updateButton(currentIndex);

            // Show next image
            carouselImages[currentIndex].style.opacity = '0.5'; // Initial opacity
        }

        // Function to restart carousel timer
        function restartCarousel() {
            if (carouselInterval) clearInterval(carouselInterval);
            carouselInterval = setInterval(showNextImage, 5000); // Change image every 5 seconds
        }

        // Start the carousel immediately
        window.addEventListener('load', function() {
            // Show first image immediately if there's no need for a delay
            showNextImage();
            // Then start the interval
            restartCarousel();
        });

        // Scroll behavior
        window.addEventListener("scroll", function() {
            let scrollTop = window.pageYOffset || document.documentElement.scrollTop;

            // Navbar behavior
            if (scrollTop > lastScrollTop) {
                // Scroll down
                navbar.classList.add("hide");
            } else {
                // Scroll up
                navbar.classList.remove("hide");
            }

            // Carousel and navigation buttons behavior
            if (scrollTop > 20 && scrollTop < 200) { // Adjust scroll threshold as needed
                section1.classList.add("scrolled");
                clearInterval(carouselInterval); // Stop the carousel
                // Ensure current image is fully opaque
                carouselImages.forEach(img => img.style.opacity = '0');
                carouselImages[currentIndex].style.opacity = '1';
                // Ensure button is fully visible within this scroll range
                carouselButton.style.opacity = '1';
            } else {
                section1.classList.remove("scrolled");
                // Reset to initial state when scrolling up
                carouselImages.forEach(img => img.style.opacity = '0.5');
                carouselImages[currentIndex].style.opacity = '0.5'; // Ensure current image is visible
                carouselButton.style.opacity = '0.7'; // Reset opacity if not scrolled within range
                restartCarousel(); // Restart the carousel with exact 5 seconds interval
            }

            lastScrollTop = scrollTop;
        });

        // Navigation buttons functionality
        document.querySelector('.carousel-nav.left').addEventListener('click', function() {
            // Move to previous image
            currentIndex = (currentIndex - 1 + carouselImages.length) % carouselImages.length;
            updateImages();
        });

        document.querySelector('.carousel-nav.right').addEventListener('click', function() {
            // Move to next image
            currentIndex = (currentIndex + 1) % carouselImages.length;
            updateImages();
        });

        function updateImages() {
            carouselImages.forEach(img => img.style.opacity = '0');
            carouselImages[currentIndex].style.opacity = '1';
            updateButton(currentIndex);
        }

        // Manual swipe for enlarged images
        let touchStartX = 0;
        let touchEndX = 0;

        carousel.addEventListener('touchstart', function(event) {
            touchStartX = event.touches[0].clientX;
        });

        carousel.addEventListener('touchmove', function(event) {
            touchEndX = event.touches[0].clientX;
        });

        carousel.addEventListener('touchend', function() {
            if (section1.classList.contains('scrolled')) { // Only if images are enlarged
                let diff = touchStartX - touchEndX;
                if (Math.abs(diff) > 50) { // Define a threshold for swipe
                    if (diff > 0) {
                        // Swipe Left - show next image
                        currentIndex = (currentIndex + 1) % carouselImages.length;
                    } else {
                        // Swipe Right - show previous image
                        currentIndex = (currentIndex - 1 + carouselImages.length) % carouselImages.length;
                    }
                    // Update visibility of images
                    carouselImages.forEach(img => img.style.opacity = '0');
                    carouselImages[currentIndex].style.opacity = '1';
                    // Update button
                    updateButton(currentIndex);
                }
            }
            touchStartX = 0;
            touchEndX = 0;
        });

        // Button click event to change carousel image
        carouselButton.addEventListener('click', () => {
            const index = parseInt(carouselButton.getAttribute('data-index'));
            // Hide current image
            carouselImages[currentIndex].style.opacity = '0';
            
            // Set new index
            currentIndex = index;
            
            // Show selected image
            carouselImages[currentIndex].style.opacity = '1';
            
            // Update button
            updateButton(currentIndex);
            
            // If scrolled, image should be fully opaque
            if (section1.classList.contains('scrolled')) {
                carouselImages[currentIndex].style.opacity = '1';
            }
        });
    </script>
</body>
</html>