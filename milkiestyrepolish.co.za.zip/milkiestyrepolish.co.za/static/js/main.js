document.addEventListener("DOMContentLoaded", function () {
    // Common elements across all pages
    const navbar = document.getElementById("navbar");
    const dropdowns = document.querySelectorAll(".dropdown");
    const searchButton = document.querySelector(".search-button");
    const cartButton = document.querySelector(".cart-button");
    const cartCount = document.querySelector(".cart-count");
    const searchInput = document.getElementById("search-input");
    const cartMessage = document.getElementById("cart-message");
    const textElement = document.getElementById("announcement-text");
    let lastScrollY = window.scrollY;

    // Messages for announcement bar (all pages)
    const messages = [
        "Welcome to Milkies – The Ultimate Tyre Shine!",
        "Click the WhatsApp icon to contact us.",
        "Real Winners, Real Prizes, Every Day!",
        "Sell Milkies. Grow With Us.",
        "Trusted by Drivers. Backed by Proof."
    ];
    let index = 0;

    // Common functions
    function changeMessage() {
        if (textElement) {
            index = (index + 1) % messages.length;
            textElement.textContent = messages[index];
        }
    }

    function closeAllDropdownsAndCart() {
        dropdowns.forEach(dropdown => {
            dropdown.querySelector(".dropdown-content").classList.remove("show");
            dropdown.classList.remove("drop-up", "drop-down");
        });
        if (cartMessage) cartMessage.style.display = "none";
    }

    // Announcement bar (all pages)
    if (textElement) {
        setInterval(changeMessage, 3500);
    }

    // Navbar scroll behavior (all pages)
    if (navbar) {
        window.addEventListener("scroll", function () {
            let currentScrollY = window.scrollY;
            if (currentScrollY > lastScrollY) {
                navbar.classList.remove("top");
                navbar.classList.add("bottom");
            } else {
                navbar.classList.remove("bottom");
                navbar.classList.add("top");
            }
            closeAllDropdownsAndCart();
            if (searchInput) searchInput.style.display = "none";
            lastScrollY = currentScrollY;
        });
    }

    // Dropdowns (all pages)
    dropdowns.forEach(dropdown => {
        const button = dropdown.querySelector("button");
        const content = dropdown.querySelector(".dropdown-content");
        if (button && content) {
            button.addEventListener("click", function (event) {
                event.stopPropagation();
                if (navbar.classList.contains("bottom")) {
                    dropdown.classList.add("drop-up");
                    dropdown.classList.remove("drop-down");
                } else {
                    dropdown.classList.add("drop-down");
                    dropdown.classList.remove("drop-up");
                }
                const isOpen = content.classList.contains("show");
                closeAllDropdownsAndCart();
                if (!isOpen) {
                    content.classList.add("show");
                }
            });
            // Ensure dropdown links navigate without interference
            content.querySelectorAll("a").forEach(link => {
                link.addEventListener("click", function (event) {
                    // Allow default navigation and close dropdown
                    closeAllDropdownsAndCart();
                    const href = link.getAttribute("href");
                    if (href && href !== "#") {
                        window.location.href = href; // Explicit navigation
                    }
                });
            });
        }
    });

    // Search button (all pages)
    if (searchButton && searchInput) {
        searchButton.addEventListener("click", function (event) {
            event.stopPropagation();
            searchInput.style.display = searchInput.style.display === "none" ? "block" : "none";
            closeAllDropdownsAndCart();
        });
    }

    // Cart button (all pages)
    if (cartButton && cartMessage) {
        cartButton.addEventListener("click", function (event) {
            event.stopPropagation();
            closeAllDropdownsAndCart();
            cartMessage.style.display = "block";
            setTimeout(() => {
                cartMessage.style.display = "none";
            }, 5000);
        });
    }

    // Close dropdowns and search on click outside (all pages)
    document.addEventListener("click", function (event) {
        if (navbar && !navbar.contains(event.target)) {
            closeAllDropdownsAndCart();
            if (searchInput) searchInput.style.display = "none";
        }
    });

    // Home page specific
    const spinImages = document.querySelectorAll(".spin-wheel");
    const heading = document.querySelector(".spin-wheel-heading");
    const subheading = document.querySelector(".spin-wheel-subheading");
    const whatsappButton = document.querySelector(".whatsapp-button");
    const productControls = document.querySelectorAll(".product-controls");

    if (spinImages.length > 0) {
        // Spin wheel cycling
        let currentImageIndex = 0;
        function cycleImages() {
            spinImages[currentImageIndex].classList.remove("active");
            currentImageIndex = (currentImageIndex + 1) % spinImages.length;
            spinImages[currentImageIndex].classList.add("active");
        }
        setInterval(cycleImages, 200);

        // Scroll behavior for heading/subheading
        window.addEventListener("scroll", function () {
            let currentScrollY = window.scrollY;
            let scrollPercentage = (currentScrollY / window.innerHeight) * 100;
            if (scrollPercentage >= 75) {
                heading.style.opacity = 0;
                subheading.style.opacity = 0;
            } else if (scrollPercentage >= 50) {
                heading.style.opacity = 0;
                subheading.style.opacity = 0.5;
            } else if (scrollPercentage >= 25) {
                heading.style.opacity = 0.5;
                subheading.style.opacity = 1;
            } else {
                heading.style.opacity = 1;
                subheading.style.opacity = 1;
            }
            if (whatsappButton) whatsappButton.style.display = "block";
        });

        // Product controls and cart count
        if (productControls.length > 0) {
            // Initialize quantities from template variables
            let quantities = {
                'tyre-polish': parseInt("{{ single }}") || 0,
                'tyre-polish-6pack': parseInt("{{ sixpack }}") || 0
            };

            function updateCartCount() {
                const totalBottles = quantities['tyre-polish'] + (quantities['tyre-polish-6pack'] * 6);
                if (cartCount) {
                    cartCount.textContent = totalBottles;
                    cartCount.classList.toggle('show', totalBottles > 0);
                }
            }

            productControls.forEach(control => {
                const productId = control.querySelector(".cart-button").dataset.product;
                const minusButton = control.querySelector(".minus");
                const plusButton = control.querySelector(".plus");
                const quantityDisplay = control.querySelector(".quantity-display");
                const cartButton = control.querySelector(".cart-button");

                if (minusButton && plusButton && quantityDisplay && cartButton) {
                    minusButton.addEventListener("click", function () {
                        if (quantities[productId] > 0) {
                            quantities[productId]--;
                            quantityDisplay.textContent = quantities[productId];
                            updateCartCount();
                        }
                    });

                    plusButton.addEventListener("click", function () {
                        quantities[productId]++;
                        quantityDisplay.textContent = quantities[productId];
                        updateCartCount();
                    });

                    cartButton.addEventListener("click", function () {
                        if (quantities[productId] > 0) {
                            fetch("{{ url_for('cart') }}", {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/x-www-form-urlencoded",
                                },
                                body: `product=${productId}&quantity=${quantities[productId]}&single=${quantities['tyre-polish']}&sixpack=${quantities['tyre-polish-6pack']}`
                            }).then(() => {
                                window.location.href = "{{ url_for('cart') }}?single=" + quantities['tyre-polish'] + "&sixpack=" + quantities['tyre-polish-6pack'];
                            });
                        }
                    });
                }
            });

            // Initial cart count update
            updateCartCount();
        }
    }

    // Cart, Checkout, and Profile pages specific
    if (!spinImages.length && cartCount) {
        // Update cart count visibility
        const totalBottles = parseInt("{{ single + (sixpack * 6) }}") || 0;
        cartCount.classList.toggle('show', totalBottles > 0);
    }
});